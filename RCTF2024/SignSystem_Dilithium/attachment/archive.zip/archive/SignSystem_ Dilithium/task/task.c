#include <stddef.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include "../randombytes.h"
#include "../sign.h"
#include <signal.h>

#define MLEN 64
#define ROUND 18

int main(void)
{
  setvbuf(stdin, 0LL, 2, 0LL);
  setvbuf(stdout, 0LL, 2, 0LL);
  setvbuf(stderr, 0LL, 2, 0LL);
  unsigned int i, j, chance = ROUND, choice;
  int ret;
  size_t mlen, smlen;
  char welcome[] = "Welcome to my dilithium task, you can forge the signature if you can!";
  char guideline[] = "Please input the number you want to choose:\n[1] sign for a message\n[2] forge the signature\n[3] exit\n> ";
  uint8_t  target[] = "yijiujiuqinian, woxuehuilekaiqiche, shangpoxiapoyasileyiqianduo.";

  uint8_t m[MLEN] = {0};
  uint8_t sm[MLEN + CRYPTO_BYTES], sm2[sizeof(target) - 1 + CRYPTO_BYTES]={0};
  uint8_t m2[MLEN + CRYPTO_BYTES];
  uint8_t pk[CRYPTO_PUBLICKEYBYTES];
  uint8_t sk[CRYPTO_SECRETKEYBYTES];
  crypto_sign_keypair(pk, sk);
  printf("%s\n", welcome);
  printf("This is your public key: ");
  for(i = 0; i < CRYPTO_PUBLICKEYBYTES; i++){
    printf("%02x", pk[i]);
  }
  printf("\n");

  while(1) {
    alarm(32);
    printf("%s", guideline);
    scanf("%d", &choice);
    getchar();
    if (choice == 1){
      alarm(5);
      if(chance > 0){
        chance -= 1;
        printf("Please input the message: ");
        // fflush(stdin);
        int c;
        size_t length = 0; 
        while ((c = getchar()) != '\n' && c != EOF) {
            if (length < MLEN-1) {
                m[length++] = (uint8_t)c;
            } else {
                while ((c = getchar()) != '\n' && c != EOF);
                break;
            }
        }
        m[length] = '\0';

        // check m != target
        if (strcmp(m, target) == 0){
          printf("You can't sign the target message! :p\n");
          continue;
        }
        
        crypto_sign(sm, &smlen, m, length, sk);
        ret = crypto_sign_open(m2, &mlen, sm, smlen, pk);
        
        if(ret){
          printf("Verification failed\n");
          return -1;
        }
        if(mlen != length) {
          fprintf(stderr, "Message lengths don't match\n");
          return -1;
        }

        for(j = 0; j < mlen; ++j) {
          if(m[j] != m2[j]) {
            fprintf(stderr, "Messages don't match\n");
            printf("%d %d %d\n", j, m[j], m2[j]);
            return -1;
          }
        }

        printf("You have signed the message successfully\n");
        //print the signature
        for (int i = 0; i < smlen; i++) {
          printf("%02x", sm[i]);
        }
        printf("\n");
        memset(sm, 0, sizeof(sm));
      }
      else{
        printf("You have no chance to sign the message\n");
        return 0;
      }
    } else if (choice == 2) {
            char smstr[2*(MLEN + CRYPTO_BYTES)] = {0};
            char *endptr;
            printf("Please input the signature (as hex):\n");
            scanf("%s", smstr); 
            for(int i = 0; i < sizeof(smstr)/2; i++){
              char tmp[3];
              strncpy(tmp, smstr + 2*i, 2);
              sm2[i] = strtol(tmp, &endptr, 16);
            }
            smlen = sizeof(sm2);
            ret = crypto_sign_open(m2, &mlen, sm2, smlen, pk);
            
            memset(sm2, 0, sizeof(sm2));
            if (ret) {
                printf("Verification failed\n");
                return -1;
            }
            if (mlen != sizeof(target) - 1) {
              printf("Message lengths don't match\n");
              printf("%d %d\n", mlen, sizeof(target));
              return -1;
            }
            for(i = 0; i < sizeof(target) - 1; i++){
              if (m2[i] != target[i]){
                printf("You can't forge the signature!\n");
                return -1;
              }
            }
            printf("Congratulations! You have forged the signature!\n");
            printf("This is your flag: ");
            FILE *file;
            char buffer[256];
            file = fopen("flag.txt", "r");
            if(file == NULL) {
                perror("error opening file");
                return 1;
            }
            if(fgets(buffer, sizeof(buffer), file) != NULL){
                    printf("%s\n", buffer);
              } else{
                    printf("error\n");
              }
              fclose(file);

            return 0;
            
        } else if (choice == 3){
      return 0;
    } else
    {
      printf("Invalid choice\n");
      return 0;
    }
    
  }

  return 0;
}
